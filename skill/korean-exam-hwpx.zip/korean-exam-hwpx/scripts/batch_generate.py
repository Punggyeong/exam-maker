#!/usr/bin/env python3
"""문제집 일괄 변형 문제 생성기.

문제집(수능특강 등) 파일 하나를 주면:
  1) 텍스트 추출 (pdf/hwpx/hwp/txt)
  2) Claude API로 지문 자동 분리
  3) 지문마다 변형 문제 원고(exam-md) 생성
  4) 지문별 문제지+해설지 hwpx 저장

사용법:
    export ANTHROPIC_API_KEY=sk-ant-...        (또는 --api-key)
    python batch_generate.py 수능특강.pdf
    python batch_generate.py 수능특강.pdf -o 출력폴더 --questions 5 --model claude-sonnet-5

특징:
  - 중간 결과(지문 목록, 원고)를 작업폴더에 저장하므로, 중단돼도 재실행하면 이어서 진행.
  - 이미 생성된 지문은 건너뜀. 비용은 호출한 만큼만 발생.

필요 패키지: python-hwpx  (pip install python-hwpx --break-system-packages)
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_exam_hwpx import parse_exam, Renderer, _profiles  # noqa: E402
from extract_text import extract  # noqa: E402

API_URL = "https://api.anthropic.com/v1/messages"
CHUNK = 18000          # 지문 분리 시 한 번에 보내는 글자 수
OVERLAP = 2500

SEGMENT_PROMPT = """다음은 국어 문제집(교재)에서 추출한 텍스트의 일부다.
이 텍스트에 포함된 '지문'(독서/문학 작품 본문)을 모두 찾아 JSON 배열로만 출력하라.

규칙:
- 각 원소는 {"title": "지문을 대표하는 짧은 제목(작품명·주제)", "genre": "독서|현대시|고전시가|현대소설|고전소설|극·수필|기타", "text": "지문 전문"}.
- text는 원문을 한 글자도 바꾸지 말고 그대로 복사한다(문항·해설·머리말·쪽번호는 제외).
- 발문, 선지(①~⑤), 해설, 학습활동, 어휘 풀이는 지문이 아니다.
- 텍스트 마지막에 잘려서 불완전한 지문은 제외한다.
- 지문이 없으면 [] 를 출력한다.
- JSON 외의 다른 말은 출력하지 않는다."""

GENERATE_PROMPT = """당신은 대한민국 수능·내신 국어 출제 전문가다. 주어진 지문으로 내신 대비 변형 문제를 만들고, 아래 exam-md 형식만 출력한다(설명·인사·코드블록 금지).

형식:
# 제목
@꼬리말: 국어의 풍경
## [1~N] 안내문(예: 다음 글을 읽고 물음에 답하시오.)
(지문) ... (/지문)      ← 준 지문을 그대로 사용(한 글자도 바꾸지 않음), 빈 줄로 문단 구분
### 1. 발문 (n점)
(보기) ... (/보기)      ← 필요한 문항에만
① ~ ⑤ 선지 5개
(태그) {tag}
(정답) 원문자
(해설) 정답 근거(지문 위치)와 주요 오답 배제 이유

출제 원칙:
- 문항 수는 {n}개. 유형을 다양하게: 내용 일치/추론, 서술상·표현상 특징, <보기> 연계 감상(외적 준거), 세부 구절(㉠~㉤ 또는 밑줄) 의미, 어휘의 문맥적 의미.
- 갈래에 맞는 발문 사용(문학: 표현상 특징·화자/인물·감상, 독서: 내용 전개·추론·구체 사례 적용).
- 구절 문항을 낼 때는 지문 안 해당 구절에 ㉠㉡㉢㉣㉤ 기호를 붙이고 __밑줄__ 처리한다(그 외 지문 변형 금지).
- 선지 5개, 길이·구조 평행. 정답 번호는 문항 간 고르게 분산.
- 오답은 지문을 살짝 비튼 매력적 오답으로. 근거 없는 애매한 선지 금지.
- 모든 문항에 (정답)과 (해설) 필수. 배점은 2~4점 분산."""


def api_call(key: str, model: str, system: str, user: str, max_tokens: int = 16000) -> str:
    body = json.dumps({
        "model": model, "max_tokens": max_tokens, "system": system,
        "messages": [{"role": "user", "content": user}],
    }).encode("utf-8")
    req = urllib.request.Request(API_URL, data=body, headers={
        "content-type": "application/json",
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
    })
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=600) as r:
                data = json.loads(r.read().decode("utf-8"))
            return "".join(b.get("text", "") for b in data.get("content", []))
        except urllib.error.HTTPError as e:
            if e.code in (429, 529, 500) and attempt < 3:
                wait = 15 * (attempt + 1)
                print(f"   API {e.code} — {wait}초 후 재시도...")
                time.sleep(wait)
                continue
            raise RuntimeError(f"API 오류 {e.code}: {e.read().decode('utf-8')[:300]}") from e
    raise RuntimeError("API 재시도 초과")


def strip_fence(s: str) -> str:
    s = s.strip()
    s = re.sub(r"^```[a-z]*\n?", "", s)
    return re.sub(r"```\s*$", "", s).strip()


def segment_passages(text: str, key: str, model: str) -> list[dict]:
    chunks = []
    i = 0
    while i < len(text):
        chunks.append(text[i:i + CHUNK])
        i += CHUNK - OVERLAP
    passages, seen = [], set()
    for n, ch in enumerate(chunks, 1):
        print(f" - 지문 분리 {n}/{len(chunks)} 구간...")
        out = strip_fence(api_call(key, model, SEGMENT_PROMPT, ch))
        try:
            items = json.loads(out)
        except json.JSONDecodeError:
            m = re.search(r"\[.*\]", out, re.S)
            items = json.loads(m.group(0)) if m else []
        for it in items:
            t = (it.get("text") or "").strip()
            if len(t) < 300:          # 너무 짧으면 지문이 아님
                continue
            fp = re.sub(r"\s+", "", t)[:60]
            if fp in seen:
                continue
            seen.add(fp)
            passages.append({"title": it.get("title", f"지문{len(passages)+1}"),
                             "genre": it.get("genre", "기타"), "text": t})
    return passages


def main():
    ap = argparse.ArgumentParser(description="문제집 → 지문별 변형 문제 hwpx 일괄 생성")
    ap.add_argument("input", help="문제집 파일 (pdf/hwpx/hwp/txt)")
    ap.add_argument("-o", "--outdir", default=None, help="출력 폴더 (기본: 입력파일과 같은 폴더의 '<이름>_변형문제')")
    ap.add_argument("--questions", type=int, default=5, help="지문당 문항 수 (기본 5)")
    ap.add_argument("--model", default="claude-sonnet-5")
    ap.add_argument("--api-key", default=None)
    ap.add_argument("--tag", default="변형", help="교사용정답 앞 출처 태그")
    ap.add_argument("--max-passages", type=int, default=0, help="처리할 최대 지문 수 (0=전부)")
    ap.add_argument("--answer-color", default="#FFFFFF")
    ap.add_argument("--profile", default="changjo", choices=["changjo", "suneung"])
    args = ap.parse_args()

    key = args.api_key or os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        sys.exit("API 키가 필요합니다: --api-key 또는 환경변수 ANTHROPIC_API_KEY")

    src = Path(args.input)
    outdir = Path(args.outdir) if args.outdir else src.parent / f"{src.stem}_변형문제"
    work = outdir / "_작업"
    work.mkdir(parents=True, exist_ok=True)

    # 1) 텍스트 추출 (캐시)
    txt_cache = work / "추출텍스트.txt"
    if txt_cache.exists():
        text = txt_cache.read_text(encoding="utf-8")
        print(f"[1/4] 텍스트 추출 — 캐시 사용 ({len(text)}자)")
    else:
        print("[1/4] 텍스트 추출 중...")
        text = extract(src)
        txt_cache.write_text(text, encoding="utf-8")
        print(f"      {len(text)}자 추출")

    # 2) 지문 분리 (캐시)
    seg_cache = work / "지문목록.json"
    if seg_cache.exists():
        passages = json.loads(seg_cache.read_text(encoding="utf-8"))
        print(f"[2/4] 지문 분리 — 캐시 사용 ({len(passages)}개)")
    else:
        print("[2/4] 지문 분리 중...")
        passages = segment_passages(text, key, args.model)
        seg_cache.write_text(json.dumps(passages, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"      지문 {len(passages)}개 발견: " + ", ".join(p["title"] for p in passages[:10])
              + (" ..." if len(passages) > 10 else ""))
    if not passages:
        sys.exit("지문을 찾지 못했습니다. 추출텍스트.txt를 확인해 주세요(스캔 PDF면 OCR 필요).")
    if args.max_passages:
        passages = passages[:args.max_passages]

    # 3) 지문별 원고 생성 (캐시)
    print(f"[3/4] 변형 문제 생성 (지문당 {args.questions}문항)...")
    system = GENERATE_PROMPT.format(n=args.questions, tag=args.tag)
    mds = []
    for i, p in enumerate(passages, 1):
        safe = re.sub(r'[\\/:*?"<>|]', "_", p["title"])[:30]
        md_path = work / f"{i:02d}_{safe}.md"
        if md_path.exists():
            print(f" - ({i}/{len(passages)}) {p['title']} — 캐시 사용")
        else:
            print(f" - ({i}/{len(passages)}) {p['title']} 출제 중...")
            user = (f"[갈래] {p['genre']}\n[지문 제목] {p['title']}\n\n[지문]\n{p['text']}\n\n"
                    f"제목은 '{p['title']} 변형 문제'로 하라.")
            md = strip_fence(api_call(key, args.model, system, user))
            try:
                parse_exam(md)          # 문법 검증, 실패 시 1회 재생성
            except Exception as e:
                print(f"   원고 문법 오류({e}) — 재생성...")
                md = strip_fence(api_call(key, args.model,
                                          system + "\n\n형식 오류가 있었다. exam-md 문법을 정확히 지켜라.", user))
                parse_exam(md)
            md_path.write_text(md, encoding="utf-8")
        mds.append((i, safe, md_path))

    # 4) hwpx 생성
    print("[4/4] hwpx 생성...")
    profile = _profiles(args.answer_color)[args.profile]
    ok = 0
    for i, safe, md_path in mds:
        try:
            exam = parse_exam(md_path.read_text(encoding="utf-8"))
            r = Renderer(profile, two_column=True)
            r.render_exam(exam)
            r.save(outdir / f"{i:02d}_{safe}_문제지.hwpx")
            r2 = Renderer(profile, two_column=False)
            r2.render_solutions(exam)
            r2.save(outdir / f"{i:02d}_{safe}_해설지.hwpx")
            ok += 1
        except Exception as e:
            print(f" - {safe}: 실패 — {e}")
    print(f"\n완료: {ok}/{len(mds)}개 지문 → {outdir}")
    print("원고(md)는 '_작업' 폴더에 있으니 문항 수정 후 build_exam_hwpx.py로 재생성할 수 있습니다.")


if __name__ == "__main__":
    main()
